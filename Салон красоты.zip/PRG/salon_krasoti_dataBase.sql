CREATE DATABASE  IF NOT EXISTS `salon_krasoti` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;
USE `salon_krasoti`;
-- MySQL dump 10.13  Distrib 8.0.15, for Win64 (x86_64)
--
-- Host: localhost    Database: salon_krasoti
-- ------------------------------------------------------
-- Server version	8.0.15

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ФИО_клиента` text NOT NULL,
  `Дата_рождения` text,
  `Адрес` text,
  `Телефон` text NOT NULL,
  `Дата` text NOT NULL,
  `Время` text NOT NULL,
  `id_service` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_service` (`id_service`),
  CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`id_service`) REFERENCES `service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Лукашеновна Мария','19 марта 2019 г.','г.Минск ул.Серова','+375(33)4352222','30 марта 2019 г.','17:00',37),(2,'Николаева Анна','2 ноября 2001 г.','Малинина','+375(33)7675555','1 апреля 2019 г.','20:00',9),(3,'Малиновская Александра','20 ноября 2002 г.','Солтыса 72-28','+375(25)1349876','7 апреля 2019 г.','18:00',25),(4,'Магнитогорский Павел','26 ноября 1994 г.','Кижеватова','+375(44)7653232','22 марта 2019 г.','18:00',26),(5,'Московская Василиса','19 июля 2094 г.','Будущее','+375(29)6547878','30 марта 2019 г.','17:00',41);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `masters`
--

DROP TABLE IF EXISTS `masters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `masters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ФИО_мастера` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `masters`
--

LOCK TABLES `masters` WRITE;
/*!40000 ALTER TABLE `masters` DISABLE KEYS */;
INSERT INTO `masters` VALUES (1,'Цагойко Лёня'),(2,'Чевнова Юля'),(3,'Ушакова Ника'),(4,'Сагитов Олег'),(5,'Долгоруков Артём'),(6,'Лазовенко Андрей'),(7,'Литвинова Юля'),(8,'Дубаневич Кристина'),(9,'Денковский Никита'),(10,'Яблонский Олег'),(11,'Антонович Саша'),(12,'Ковалевский Никита');
/*!40000 ALTER TABLE `masters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Название` text NOT NULL,
  `Цена` double NOT NULL,
  `Тип` text NOT NULL,
  `id_master` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_master` (`id_master`),
  CONSTRAINT `service_ibfk_1` FOREIGN KEY (`id_master`) REFERENCES `masters` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` VALUES (1,'Классическая стрижка',25,'М',10),(2,'Бокс',30,'М',1),(3,'Полубокс',30,'М',1),(4,'Каре',25,'М',10),(5,'Ёжик',28,'М',11),(6,'Канадка',35,'М',1),(7,'Спортивная',25,'М',10),(8,'Каскад',28,'М',11),(9,'Андеркат',30,'М',11),(10,'Локоны',50,'П',3),(11,'Греческая коса',65,'П',3),(12,'Высокий пучок',68,'П',3),(13,'Средний пучок',70,'П',3),(14,'Низкий пучок',68,'П',3),(15,'Фактурный хвост',58,'П',3),(16,'Греческий хвост',60,'П',3),(17,'Классическая стрижка',30,'Ж',6),(18,'Каре',30,'Ж',6),(19,'Каскад',35,'Ж',4),(20,'Пикси',40,'Ж',2),(21,'Шапочка',38,'Ж',6),(22,'Боб',40,'Ж',2),(23,'Боб-каре',43,'Ж',2),(24,'Ирокез',37,'Ж',4),(25,'Стрижка с выбритым виском',43,'Ж',4),(26,'Общий массаж (60 мин)',60,'Массаж',5),(27,'Массаж спины (30 мин)',24,'Массаж',5),(28,'Массаж живота (15 мин)',15,'Массаж',9),(29,'Массаж нижних конечностей (20 мин)',19,'Массаж',12),(30,'Массаж верхних конечностей (20 мин)',19,'Массаж',12),(31,'Массаж головы (15 мин)',15,'Массаж',9),(32,'Маникюр классический',14,'Н',7),(33,'Маникюр европейский',14,'Н',8),(34,'Обрезной маникюр + однотонное покрытие гель-лаком',30,'Н',7),(35,'Аппаратный маникюр + однотонное покрытие гель-лаком',33,'Н',8),(36,'Мужской маникюр',22,'Н',7),(37,'Наращивание + долговременное покрытие',62,'Н',8),(38,'Афрокосы',150,'П',3),(39,'Дреды',200,'П',2),(41,'Коситички зизи',180,'П',3);
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-19 22:50:45
