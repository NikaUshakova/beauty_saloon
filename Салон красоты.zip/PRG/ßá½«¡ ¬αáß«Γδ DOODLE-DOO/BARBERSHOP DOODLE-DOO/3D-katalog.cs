﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
namespace BARBERSHOP_DOODLE_DOO
{
    public partial class _3D_katalog : Form
    {

        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        List<string[]> service = new List<string[]>();

        public _3D_katalog()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
          
            server = "localhost";
            database = "salon_krasoti";
            uid = "root";
            password = "zapekanka333";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            connection = new MySqlConnection(connectionString);
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                // MessageBox.Show("Соединение установлено!");
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }



        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public List<string[]> SelectService()
        {
            string query = "SELECT service.id, service.Название,service.Цена, masters.ФИО_мастера FROM service LEFT OUTER JOIN masters ON service.id_master=masters.id  WHERE service.Тип='" + type + "'";

            //Open connection
            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();
                service.Clear();
                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    service.Add(new string[4]);
                    service[service.Count - 1][0] = dataReader[0].ToString();
                    service[service.Count - 1][1] = dataReader[1].ToString();
                    service[service.Count - 1][2] = dataReader[2].ToString();
                    service[service.Count - 1][3] = dataReader[3].ToString();


                }
                RefreshInfo();
                //close Data Reader
                dataReader.Close();

                //close Connection
                this.CloseConnection();

                //return list to be displayed
                return service;
            }
            else
            {
                return service;
            }
        }


        public void RefreshInfo()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < service.Count; i++)
            {
                if (i % 2 == 0)
                {
                    dataGridView1.Rows.Add(service[i]);
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(222, 236, 255);
                }
                else
                {
                    dataGridView1.Rows.Add(service[i]);
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(243, 248, 255);
                }

            }
        }
         
        string type = "";
        private void label7_Click(object sender, EventArgs e)
        {
            type = "М";
            //dataGridView1.Size = new Size(550, 340);
            dataGridView1.Visible = true;

            SelectService();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            type = "Ж";

            dataGridView1.Visible = true;

            SelectService();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            type = "П";

            dataGridView1.Visible = true;

            SelectService();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            type = "Массаж";

            dataGridView1.Visible = true;

            SelectService();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            type = "Н";

            dataGridView1.Visible = true;

            SelectService();
        }

        private void label7_MouseMove(object sender, MouseEventArgs e)
        {
            label7.ForeColor = Color.DarkBlue;
        }

        private void label8_MouseMove(object sender, MouseEventArgs e)
        {
            label8.ForeColor = Color.DarkBlue;
        }

        private void label9_MouseMove(object sender, MouseEventArgs e)
        {
            label9.ForeColor = Color.DarkBlue;

        }

        private void label10_MouseMove(object sender, MouseEventArgs e)
        {
            label10.ForeColor = Color.DarkBlue;
        }

        private void label11_MouseMove(object sender, MouseEventArgs e)
        {
            label11.ForeColor = Color.DarkBlue;
        }

        private void label7_MouseLeave(object sender, EventArgs e)
        {
            label7.ForeColor = Color.Black;
        }

        private void label8_MouseLeave(object sender, EventArgs e)
        {
            label8.ForeColor = Color.Black;
        }

        private void label9_MouseLeave(object sender, EventArgs e)
        {
            label9.ForeColor = Color.Black;
        }

        private void label10_MouseLeave(object sender, EventArgs e)
        {
            label10.ForeColor = Color.Black;
        }

        private void label11_MouseLeave(object sender, EventArgs e)
        {
            label11.ForeColor = Color.Black;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainMenuUser menuUser = new MainMenuUser();
            menuUser.Show();
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = DOODLE_DOO.Properties.Resources.exit__;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = DOODLE_DOO.Properties.Resources.exit;
        }

        private void _3D_katalog_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainMenuUser menuUser = new MainMenuUser();
            menuUser.Show();
        }
    }
}
