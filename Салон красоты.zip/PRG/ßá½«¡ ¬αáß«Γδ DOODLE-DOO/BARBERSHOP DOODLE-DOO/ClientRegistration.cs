﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BARBERSHOP_DOODLE_DOO
{
    class ClientRegistration
    {
        public string LoginUser { get; private set; }
        public string PassUser { get; private set; }

        public ClientRegistration(string LoginUser, string PassUser)
        {
            this.LoginUser = LoginUser;
            this.PassUser = PassUser;
        }
    } 
}
