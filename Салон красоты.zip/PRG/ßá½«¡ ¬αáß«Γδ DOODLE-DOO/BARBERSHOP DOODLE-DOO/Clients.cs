﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BARBERSHOP_DOODLE_DOO
{
   public class Clients
    {
        public string Name { get; set; }
        public string Surname { get; set; }
        public string HB { get; set; }
        public string Adress { get; set; }
        public string Mobile { get; set; }

        public Clients(string Name, string Surname, string HB, string Adress, string Mobile)
        {
            this.Name = Name;
            this.Surname = Surname;
            this.HB = HB;
            this.Adress = Adress;
            this.Mobile = Mobile;
        }
    }
}
