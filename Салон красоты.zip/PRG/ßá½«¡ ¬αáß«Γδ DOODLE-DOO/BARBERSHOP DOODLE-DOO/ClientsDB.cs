﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
                                                                                             
using MySql.Data.MySqlClient;
namespace BARBERSHOP_DOODLE_DOO
{
    public partial class ClientsDB : Form
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        List<string[]> clients = new List<string[]>();
        public ClientsDB()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
           
            server = "localhost";
            database = "salon_krasoti";
            uid = "root";
            password = "zapekanka333";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            connection = new MySqlConnection(connectionString);
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
               // MessageBox.Show("Соединение установлено!");
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public List<string[]> SelectClients()
        {
            string query = "SELECT clients.id,clients.ФИО_клиента,clients.Дата_рождения,clients.Адрес,clients.Телефон," +
                "service.Название,clients.Дата, clients.Время from clients " +
                "LEFT OUTER JOIN service ON clients.id_service=service.id Group BY clients.id";


            //Open connection
            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();
                clients.Clear();
                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    clients.Add(new string[8]);
                    clients[clients.Count - 1][0] = dataReader[0].ToString();
                    clients[clients.Count - 1][1] = dataReader[1].ToString();
                    clients[clients.Count - 1][2] = dataReader[2].ToString();
                    clients[clients.Count - 1][3] = dataReader[3].ToString();
                    clients[clients.Count - 1][4] = dataReader[4].ToString();
                    clients[clients.Count - 1][5] = dataReader[5].ToString();
                    clients[clients.Count - 1][6] = dataReader[6].ToString();
                    clients[clients.Count - 1][7] = dataReader[7].ToString();
                    

                }
                RefreshInfo();
                //close Data Reader
                dataReader.Close();

                //close Connection
                this.CloseConnection();

                //return list to be displayed
                return clients;
            }
            else
            {
                return clients;
            }
        }
        public void RefreshInfo()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < clients.Count; i++)
            {
                if (i % 2 == 0)
                {
                    dataGridView1.Rows.Add(clients[i]);
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(222, 236, 255);
                }
                else
                {
                    dataGridView1.Rows.Add(clients[i]);
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(243, 248, 255);
                }

            }

        }

       
        private void ClientsDB_Load(object sender, EventArgs e)
        {
            SelectClients();
         
        }

        private void pictureExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureExit_MouseLeave(object sender, EventArgs e)
        {
            pictureExit.Image = DOODLE_DOO.Properties.Resources.exit;
        }

        private void pictureExit_MouseMove(object sender, MouseEventArgs e)
        {
            pictureExit.Image = DOODLE_DOO.Properties.Resources.exit__;
        }

        private void pictureDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 1)
            {
                DialogResult result = MessageBox.Show(
                            "Вы действительно хотите очистить весь список клиентов?",
                             "Attention",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question,
                            MessageBoxDefaultButton.Button1,
                            MessageBoxOptions.DefaultDesktopOnly);
                // Проверяем какая кнопка нажата ...             
                if (result == DialogResult.Yes)
                {
                    
                    Delete();
                    dataGridView1.Rows.Clear();
                    
                }
                else
                {
                    this.TopMost = true;
                }// Ставим нашу форму по верх всех окон  
                this.TopMost = true;
            }
            else {
                MessageBox.Show("Список пуст!","Attention");
                return;
            }
           
        }

        private void pictureDelete_MouseLeave(object sender, EventArgs e)
        {
            pictureDelete.Image = DOODLE_DOO.Properties.Resources.delete;
        }

        private void pictureDelete_MouseMove(object sender, MouseEventArgs e)
        {
            pictureDelete.Image = DOODLE_DOO.Properties.Resources.delete__;
        }

        private void pictureSort_MouseLeave(object sender, EventArgs e)
        {
            pictureSort.Image = DOODLE_DOO.Properties.Resources.sort;
        }

        private void pictureSort_MouseMove(object sender, MouseEventArgs e)
        {
            pictureSort.Image = DOODLE_DOO.Properties.Resources.sort__;
        }

        private void pictureSort_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            Sort(); 

        }
                                                                      //СОРТИРОВКААААА 
        //sort statement
        public List<string[]> Sort() 
        {
        
            string query = "SELECT clients.id,clients.ФИО_клиента,clients.Дата_рождения,clients.Адрес,clients.Телефон," +
                "service.Название,clients.Дата, clients.Время from clients " +
                "LEFT OUTER JOIN service ON clients.id_service=service.id ORDER BY clients.ФИО_клиента asc;";

            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();
                clients.Clear();
                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    clients.Add(new string[8]);
                    clients[clients.Count - 1][0] = dataReader[0].ToString();
                    clients[clients.Count - 1][1] = dataReader[1].ToString();
                    clients[clients.Count - 1][2] = dataReader[2].ToString();
                    clients[clients.Count - 1][3] = dataReader[3].ToString();
                    clients[clients.Count - 1][4] = dataReader[4].ToString();
                    clients[clients.Count - 1][5] = dataReader[5].ToString();
                    clients[clients.Count - 1][6] = dataReader[6].ToString();
                    clients[clients.Count - 1][7] = dataReader[7].ToString();
                

                }
              
                RefreshInfo();
                //close Data Reader
                dataReader.Close();

                //close Connection
                this.CloseConnection();

                //return list to be displayed
                return clients;
            }
            else
            { 
                return clients;
            }
        }
                                                                                        //ТИПО ПОИСК 
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();

            for (int i = 0; i < clients.Count; i++)
            {

                if ((clients[i][1]).Contains(textBox1.Text))
                {
                    dataGridView1.Rows.Add(clients[i]);        

                }
            }
        }
     

        public void Delete()                                    
        {
            string query = "truncate clients ";

            if (this.OpenConnection() == true)
            {
                MySqlCommand cmd = new MySqlCommand(query, connection);
                
                cmd.ExecuteNonQuery();

                this.CloseConnection();
            }
        }
               
        private void ClientsDB_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainMenuAdmin menuAdmin = new MainMenuAdmin();
            menuAdmin.Show();
            this.Hide();
        }

       
        private void удалитьВыбранногоКлиентаToolStripMenuItem_Click(object sender, EventArgs e)     ////УДАЛЕНИЕ ВЫБРАННОГО КЛИЕНТА
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string valuee = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                int value = int.Parse(valuee);
                string query = "DELETE FROM clients WHERE clients.id = " + value;

                if (this.OpenConnection() == true)
                {
                    MySqlCommand cmd = new MySqlCommand(query, connection);

                    cmd.ExecuteNonQuery();

                    this.CloseConnection();
                }
                dataGridView1.Rows.Clear();
                SelectClients();

            }
            else
            {
                MessageBox.Show("Клиентов нет");
                return;
            }
        }
    }
       
    
}
