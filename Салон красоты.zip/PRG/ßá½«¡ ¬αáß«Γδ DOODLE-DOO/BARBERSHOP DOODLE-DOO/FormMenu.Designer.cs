﻿namespace BARBERSHOP_DOODLE_DOO
{
    partial class FormMenu
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenu));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.справкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПррограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enteradmin = new System.Windows.Forms.Button();
            this.passworAdmin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.loginAdmin = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupAdmin = new System.Windows.Forms.GroupBox();
            this.checkBoxadmin = new System.Windows.Forms.CheckBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.backadmin = new System.Windows.Forms.Button();
            this.groupUser = new System.Windows.Forms.GroupBox();
            this.checkBoxreg = new System.Windows.Forms.CheckBox();
            this.repeatpassuser = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.regpassuser = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.regloginuser = new System.Windows.Forms.TextBox();
            this.backreg = new System.Windows.Forms.Button();
            this.buttonReg = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureExit = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.groupAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupUser.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureExit)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Font = new System.Drawing.Font("Comic Sans MS", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.Location = new System.Drawing.Point(152, 249);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(479, 214);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "АВТОРИЗАЦИЯ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(248, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 29);
            this.label4.TabIndex = 4;
            this.label4.Text = "Пользователь";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox4.Image = global::DOODLE_DOO.Properties.Resources.community1;
            this.pictureBox4.Location = new System.Drawing.Point(253, 7);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(153, 192);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(40, 178);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Администратор";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::DOODLE_DOO.Properties.Resources.businessman;
            this.pictureBox1.Location = new System.Drawing.Point(57, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(150, 192);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.Info;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.справкаToolStripMenuItem,
            this.оПрограммеToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(790, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // справкаToolStripMenuItem
            // 
            this.справкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.справкаToolStripMenuItem1});
            this.справкаToolStripMenuItem.Name = "справкаToolStripMenuItem";
            this.справкаToolStripMenuItem.Size = new System.Drawing.Size(79, 24);
            this.справкаToolStripMenuItem.Text = "Справка";
            // 
            // справкаToolStripMenuItem1
            // 
            this.справкаToolStripMenuItem1.Name = "справкаToolStripMenuItem1";
            this.справкаToolStripMenuItem1.Size = new System.Drawing.Size(142, 26);
            this.справкаToolStripMenuItem1.Text = "Справка";
            this.справкаToolStripMenuItem1.Click += new System.EventHandler(this.справкаToolStripMenuItem1_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.оПррограммеToolStripMenuItem});
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(116, 24);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            // 
            // оПррограммеToolStripMenuItem
            // 
            this.оПррограммеToolStripMenuItem.Name = "оПррограммеToolStripMenuItem";
            this.оПррограммеToolStripMenuItem.Size = new System.Drawing.Size(179, 26);
            this.оПррограммеToolStripMenuItem.Text = "О программе";
            this.оПррограммеToolStripMenuItem.Click += new System.EventHandler(this.оПррограммеToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // enteradmin
            // 
            this.enteradmin.BackColor = System.Drawing.Color.Lavender;
            this.enteradmin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.enteradmin.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.enteradmin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.enteradmin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.enteradmin.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.enteradmin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.enteradmin.Image = ((System.Drawing.Image)(resources.GetObject("enteradmin.Image")));
            this.enteradmin.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.enteradmin.Location = new System.Drawing.Point(304, 201);
            this.enteradmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.enteradmin.Name = "enteradmin";
            this.enteradmin.Size = new System.Drawing.Size(236, 49);
            this.enteradmin.TabIndex = 9;
            this.enteradmin.Text = "Войти";
            this.enteradmin.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.enteradmin.UseVisualStyleBackColor = false;
            this.enteradmin.Click += new System.EventHandler(this.button1_Click);
            // 
            // passworAdmin
            // 
            this.passworAdmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.passworAdmin.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passworAdmin.Location = new System.Drawing.Point(231, 102);
            this.passworAdmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.passworAdmin.MaxLength = 24;
            this.passworAdmin.Name = "passworAdmin";
            this.passworAdmin.Size = new System.Drawing.Size(275, 32);
            this.passworAdmin.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(51, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 28);
            this.label2.TabIndex = 7;
            this.label2.Text = "Введите пароль";
            // 
            // loginAdmin
            // 
            this.loginAdmin.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.loginAdmin.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginAdmin.Location = new System.Drawing.Point(231, 59);
            this.loginAdmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.loginAdmin.MaxLength = 24;
            this.loginAdmin.Name = "loginAdmin";
            this.loginAdmin.Size = new System.Drawing.Size(275, 32);
            this.loginAdmin.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(51, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 28);
            this.label1.TabIndex = 5;
            this.label1.Text = "Введите логин";
            // 
            // groupAdmin
            // 
            this.groupAdmin.BackColor = System.Drawing.Color.Lavender;
            this.groupAdmin.Controls.Add(this.checkBoxadmin);
            this.groupAdmin.Controls.Add(this.pictureBox2);
            this.groupAdmin.Controls.Add(this.backadmin);
            this.groupAdmin.Controls.Add(this.label1);
            this.groupAdmin.Controls.Add(this.enteradmin);
            this.groupAdmin.Controls.Add(this.loginAdmin);
            this.groupAdmin.Controls.Add(this.passworAdmin);
            this.groupAdmin.Controls.Add(this.label2);
            this.groupAdmin.Font = new System.Drawing.Font("Comic Sans MS", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupAdmin.Location = new System.Drawing.Point(92, 163);
            this.groupAdmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupAdmin.Name = "groupAdmin";
            this.groupAdmin.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupAdmin.Size = new System.Drawing.Size(568, 289);
            this.groupAdmin.TabIndex = 10;
            this.groupAdmin.TabStop = false;
            this.groupAdmin.Text = "LOGIN";
            this.groupAdmin.Visible = false;
            // 
            // checkBoxadmin
            // 
            this.checkBoxadmin.AutoSize = true;
            this.checkBoxadmin.Location = new System.Drawing.Point(284, 140);
            this.checkBoxadmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxadmin.Name = "checkBoxadmin";
            this.checkBoxadmin.Size = new System.Drawing.Size(209, 33);
            this.checkBoxadmin.TabIndex = 15;
            this.checkBoxadmin.Text = "Показать пароль";
            this.checkBoxadmin.UseVisualStyleBackColor = true;
            this.checkBoxadmin.CheckedChanged += new System.EventHandler(this.checkBoxadmin_CheckedChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(91, 208);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 36);
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // backadmin
            // 
            this.backadmin.BackColor = System.Drawing.Color.Lavender;
            this.backadmin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.backadmin.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.backadmin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.backadmin.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.backadmin.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backadmin.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.backadmin.Image = ((System.Drawing.Image)(resources.GetObject("backadmin.Image")));
            this.backadmin.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.backadmin.Location = new System.Drawing.Point(55, 201);
            this.backadmin.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.backadmin.Name = "backadmin";
            this.backadmin.Size = new System.Drawing.Size(183, 49);
            this.backadmin.TabIndex = 10;
            this.backadmin.Text = "Назад";
            this.backadmin.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.backadmin.UseVisualStyleBackColor = false;
            this.backadmin.Click += new System.EventHandler(this.backadmin_Click);
            // 
            // groupUser
            // 
            this.groupUser.BackColor = System.Drawing.Color.Lavender;
            this.groupUser.Controls.Add(this.checkBoxreg);
            this.groupUser.Controls.Add(this.repeatpassuser);
            this.groupUser.Controls.Add(this.label7);
            this.groupUser.Controls.Add(this.label8);
            this.groupUser.Controls.Add(this.regpassuser);
            this.groupUser.Controls.Add(this.pictureBox3);
            this.groupUser.Controls.Add(this.regloginuser);
            this.groupUser.Controls.Add(this.backreg);
            this.groupUser.Controls.Add(this.buttonReg);
            this.groupUser.Controls.Add(this.label6);
            this.groupUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupUser.Font = new System.Drawing.Font("Comic Sans MS", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupUser.Location = new System.Drawing.Point(86, 159);
            this.groupUser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupUser.Name = "groupUser";
            this.groupUser.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupUser.Size = new System.Drawing.Size(568, 289);
            this.groupUser.TabIndex = 11;
            this.groupUser.TabStop = false;
            this.groupUser.Text = "LOGIN";
            this.groupUser.Visible = false;
            // 
            // checkBoxreg
            // 
            this.checkBoxreg.AutoSize = true;
            this.checkBoxreg.Location = new System.Drawing.Point(315, 156);
            this.checkBoxreg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBoxreg.Name = "checkBoxreg";
            this.checkBoxreg.Size = new System.Drawing.Size(209, 33);
            this.checkBoxreg.TabIndex = 16;
            this.checkBoxreg.Text = "Показать пароль";
            this.checkBoxreg.UseVisualStyleBackColor = true;
            this.checkBoxreg.CheckedChanged += new System.EventHandler(this.checkBoxreg_CheckedChanged);
            // 
            // repeatpassuser
            // 
            this.repeatpassuser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.repeatpassuser.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.repeatpassuser.Location = new System.Drawing.Point(283, 116);
            this.repeatpassuser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.repeatpassuser.MaxLength = 24;
            this.repeatpassuser.Name = "repeatpassuser";
            this.repeatpassuser.Size = new System.Drawing.Size(256, 32);
            this.repeatpassuser.TabIndex = 15;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(37, 73);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 28);
            this.label7.TabIndex = 7;
            this.label7.Text = "Введите пароль";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(37, 119);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(192, 28);
            this.label8.TabIndex = 14;
            this.label8.Text = "Повторите пароль";
            // 
            // regpassuser
            // 
            this.regpassuser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.regpassuser.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regpassuser.Location = new System.Drawing.Point(283, 69);
            this.regpassuser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.regpassuser.MaxLength = 24;
            this.regpassuser.Name = "regpassuser";
            this.regpassuser.Size = new System.Drawing.Size(256, 32);
            this.regpassuser.TabIndex = 8;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(95, 233);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(53, 36);
            this.pictureBox3.TabIndex = 12;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // regloginuser
            // 
            this.regloginuser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.regloginuser.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regloginuser.Location = new System.Drawing.Point(283, 26);
            this.regloginuser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.regloginuser.MaxLength = 24;
            this.regloginuser.Name = "regloginuser";
            this.regloginuser.Size = new System.Drawing.Size(256, 32);
            this.regloginuser.TabIndex = 6;
            // 
            // backreg
            // 
            this.backreg.BackColor = System.Drawing.Color.Lavender;
            this.backreg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.backreg.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.backreg.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.backreg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.backreg.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.backreg.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.backreg.Image = ((System.Drawing.Image)(resources.GetObject("backreg.Image")));
            this.backreg.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.backreg.Location = new System.Drawing.Point(44, 226);
            this.backreg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.backreg.Name = "backreg";
            this.backreg.Size = new System.Drawing.Size(193, 50);
            this.backreg.TabIndex = 10;
            this.backreg.Text = "      Назад";
            this.backreg.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.backreg.UseVisualStyleBackColor = false;
            this.backreg.Click += new System.EventHandler(this.backreg_Click);
            // 
            // buttonReg
            // 
            this.buttonReg.BackColor = System.Drawing.Color.Lavender;
            this.buttonReg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonReg.FlatAppearance.BorderColor = System.Drawing.Color.Gainsboro;
            this.buttonReg.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.buttonReg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonReg.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonReg.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonReg.Image = ((System.Drawing.Image)(resources.GetObject("buttonReg.Image")));
            this.buttonReg.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.buttonReg.Location = new System.Drawing.Point(303, 226);
            this.buttonReg.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonReg.Name = "buttonReg";
            this.buttonReg.Size = new System.Drawing.Size(236, 50);
            this.buttonReg.TabIndex = 9;
            this.buttonReg.Text = "Войти";
            this.buttonReg.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonReg.UseVisualStyleBackColor = false;
            this.buttonReg.Click += new System.EventHandler(this.buttonReg_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(37, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(155, 28);
            this.label6.TabIndex = 5;
            this.label6.Text = "Введите логин";
            // 
            // pictureExit
            // 
            this.pictureExit.BackColor = System.Drawing.Color.Transparent;
            this.pictureExit.Image = global::DOODLE_DOO.Properties.Resources.exit1;
            this.pictureExit.Location = new System.Drawing.Point(669, 357);
            this.pictureExit.Margin = new System.Windows.Forms.Padding(4);
            this.pictureExit.Name = "pictureExit";
            this.pictureExit.Size = new System.Drawing.Size(90, 102);
            this.pictureExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureExit.TabIndex = 16;
            this.pictureExit.TabStop = false;
            this.pictureExit.Click += new System.EventHandler(this.pictureExit_Click);
            this.pictureExit.MouseLeave += new System.EventHandler(this.pictureExit_MouseLeave);
            this.pictureExit.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureExit_MouseMove);
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = global::DOODLE_DOO.Properties.Resources.Фон1;
            this.ClientSize = new System.Drawing.Size(790, 474);
            this.Controls.Add(this.groupUser);
            this.Controls.Add(this.groupAdmin);
            this.Controls.Add(this.pictureExit);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(808, 521);
            this.MinimumSize = new System.Drawing.Size(808, 521);
            this.Name = "FormMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Салон красоты \"DOODLE-DOO\"";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FormMenu_FormClosed);
            this.Load += new System.EventHandler(this.FormMenu_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupAdmin.ResumeLayout(false);
            this.groupAdmin.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupUser.ResumeLayout(false);
            this.groupUser.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureExit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.Button enteradmin;
        private System.Windows.Forms.TextBox passworAdmin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox loginAdmin; 
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupAdmin;
        private System.Windows.Forms.GroupBox groupUser;
        private System.Windows.Forms.Button backadmin;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox repeatpassuser; 
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button backreg;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonReg;
        private System.Windows.Forms.TextBox regloginuser; //
        private System.Windows.Forms.TextBox regpassuser; //
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox checkBoxadmin;
        private System.Windows.Forms.CheckBox checkBoxreg;
        private System.Windows.Forms.PictureBox pictureExit;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem оПррограммеToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label4;
    }
}

