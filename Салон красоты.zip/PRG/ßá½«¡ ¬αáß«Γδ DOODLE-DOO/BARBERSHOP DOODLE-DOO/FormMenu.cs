﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace BARBERSHOP_DOODLE_DOO
{
    public partial class FormMenu : Form
    {
        public FormMenu()
        {
            InitializeComponent();
        }
        List<ClientRegistration> clients = new List<ClientRegistration>();
        const string LoginAdmin = "Admin";
        const string PasswordAdmin = "12345678";

        private void buttonclient_Click(object sender, EventArgs e)
        { 
            groupUser.Visible = true;
            groupBox1.Visible = false;
        }

        private void backadmin_Click(object sender, EventArgs e)
        {
            groupAdmin.Visible = false;
            groupBox1.Visible = true;
            loginAdmin.Text = "";
            passworAdmin.Text = "";
        }

        private void backuser_Click(object sender, EventArgs e)
        {
            groupUser.Visible = false;
            groupBox1.Visible = true;
            
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (loginAdmin.Text.Equals(LoginAdmin) && passworAdmin.Text.Equals(PasswordAdmin))
            {
                //MessageBox.Show("Все ок", "Error");
                MainMenuAdmin menuadmin = new MainMenuAdmin();
                menuadmin.Show();
                this.Hide();
           }
            else
            {
              MessageBox.Show("Неверный логин или пароль", "Error");
                return;
            }
        }

       

        private void FormMenu_Load(object sender, EventArgs e)
        {
                       
            passworAdmin.UseSystemPasswordChar = true;
            
            regpassuser.UseSystemPasswordChar = true;
            repeatpassuser.UseSystemPasswordChar = true;
        }
                

      

        private void checkBoxadmin_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxadmin.Checked)
            {
                passworAdmin.UseSystemPasswordChar = false;
            }
            else { passworAdmin.UseSystemPasswordChar = true; }
        }

        private void checkBoxreg_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxreg.Checked)
            {
                regpassuser.UseSystemPasswordChar = false;
                repeatpassuser.UseSystemPasswordChar = false;
            }
            else
            {
                repeatpassuser.UseSystemPasswordChar = true;
                regpassuser.UseSystemPasswordChar = true;
            }
        }


        private void backreg_Click(object sender, EventArgs e)
        {
            groupUser.Visible = false;
            groupBox1.Visible = true;
            regloginuser.Text = "";
            regpassuser.Text = "";
            repeatpassuser.Text = "";

        }

        private void buttonReg_Click(object sender, EventArgs e)
        {
           
            string newlogin = regloginuser.Text;
            string newpass = regpassuser.Text;
            string repeatpass = repeatpassuser.Text;
            bool valid = false;
            if (regloginuser.Text.Length >= 6)
            {
                if (regpassuser.Text.Length >= 4)
                {
                    if (repeatpassuser.Text != "")
                    {
                        for (int i = 0; i < clients.Count; i++)
                        {
                            if (newlogin == clients[i].LoginUser)
                            {
                                MessageBox.Show("Пользователь с таким логином уже зарегистрирован!", "Attention");
                                valid = true;
                            }
                        }

                        if (!valid)
                        {
                            if (newpass == repeatpass)
                            {
                                clients.Add(new ClientRegistration(newlogin, newpass));
                                        //Проход на след форму
                                MainMenuUser user = new MainMenuUser();
                                user.Show();
                                this.Hide();
                            }
                            else
                            {
                                MessageBox.Show("Пароли не совпадают!", "Attention");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Повторите ваш пароль", "Attention");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("Длина пароля должна быть более 4 символов", "Attention");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Длина логина должна быть более 6 символов", "Attention");
                return;
            } 
            
        }

       

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            groupUser.Visible = false;
            groupBox1.Visible = true;
            regloginuser.Text = "";
            regpassuser.Text = "";
            repeatpassuser.Text = "";
        }

       

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            groupAdmin.Visible = false;
            groupBox1.Visible = true;
            loginAdmin.Text = "";
            passworAdmin.Text = "";
        }

        private void FormMenu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void pictureExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureExit_MouseMove(object sender, MouseEventArgs e)
        {
            pictureExit.Size = new Size(72, 79);
        }

        private void pictureExit_MouseLeave(object sender, EventArgs e)
        {
            pictureExit.Size = new Size(66, 71);
        }

        private void оПррограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about about = new about();
            about.Show();
            this.Hide();
        }

        private void справкаToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Process.Start("spravka.html");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            groupAdmin.Visible = true;
            groupBox1.Visible = false;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            groupAdmin.Visible = true;
            groupBox1.Visible = false;
        }

        private void pictureBox4_Click(object sender, EventArgs e
)        {
            groupUser.Visible = true;
            groupBox1.Visible = false;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            groupUser.Visible = true;
            groupBox1.Visible = false;
        }
    }
}
