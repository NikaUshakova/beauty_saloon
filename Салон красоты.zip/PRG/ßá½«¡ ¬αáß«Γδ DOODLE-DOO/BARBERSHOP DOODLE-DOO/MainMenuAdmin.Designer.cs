﻿namespace BARBERSHOP_DOODLE_DOO
{
    partial class MainMenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenuAdmin));
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.выйтиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выйтиВМенюРегистрацииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.закрытьПриложениеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.каталогУслугToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.маникюрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.педикюрToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.долговременноеПокрытиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.стрижкиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.мужскиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.женскиеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.массажToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.массажВсегоТелаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.массажГоловыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.массажСпиныToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.прайслистToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nailулсугиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.стрижкиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.массажToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.вернутьсяНаГлавнуюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выйиСУчетнойЗаписиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.закрытьПриложениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(211)))), ((int)(((byte)(255)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button1.FlatAppearance.BorderSize = 3;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Comic Sans MS", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(24, 55);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(426, 116);
            this.button1.TabIndex = 0;
            this.button1.Text = "Список клиентов";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(211)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.button2.FlatAppearance.BorderSize = 3;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Comic Sans MS", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(24, 183);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(426, 116);
            this.button2.TabIndex = 3;
            this.button2.Text = "Добавить услуги";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::DOODLE_DOO.Properties.Resources.nail_polish;
            this.pictureBox3.Location = new System.Drawing.Point(67, 333);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(92, 85);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 7;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::DOODLE_DOO.Properties.Resources.lotion;
            this.pictureBox4.Location = new System.Drawing.Point(197, 333);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(92, 85);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::DOODLE_DOO.Properties.Resources.scissors;
            this.pictureBox5.Location = new System.Drawing.Point(323, 336);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(113, 82);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 9;
            this.pictureBox5.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.panel1.Location = new System.Drawing.Point(24, 438);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(426, 14);
            this.panel1.TabIndex = 10;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выйтиToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(480, 28);
            this.menuStrip1.TabIndex = 12;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // выйтиToolStripMenuItem
            // 
            this.выйтиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выйтиВМенюРегистрацииToolStripMenuItem,
            this.закрытьПриложениеToolStripMenuItem1});
            this.выйтиToolStripMenuItem.Name = "выйтиToolStripMenuItem";
            this.выйтиToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.выйтиToolStripMenuItem.Text = "Выйти";
            // 
            // выйтиВМенюРегистрацииToolStripMenuItem
            // 
            this.выйтиВМенюРегистрацииToolStripMenuItem.Name = "выйтиВМенюРегистрацииToolStripMenuItem";
            this.выйтиВМенюРегистрацииToolStripMenuItem.Size = new System.Drawing.Size(277, 26);
            this.выйтиВМенюРегистрацииToolStripMenuItem.Text = "Выйти в меню регистрации";
            this.выйтиВМенюРегистрацииToolStripMenuItem.Click += new System.EventHandler(this.выйтиВМенюРегистрацииToolStripMenuItem_Click);
            // 
            // закрытьПриложениеToolStripMenuItem1
            // 
            this.закрытьПриложениеToolStripMenuItem1.Name = "закрытьПриложениеToolStripMenuItem1";
            this.закрытьПриложениеToolStripMenuItem1.Size = new System.Drawing.Size(277, 26);
            this.закрытьПриложениеToolStripMenuItem1.Text = "Закрыть приложение";
            this.закрытьПриложениеToolStripMenuItem1.Click += new System.EventHandler(this.закрытьПриложениеToolStripMenuItem1_Click);
            // 
            // каталогУслугToolStripMenuItem
            // 
            this.каталогУслугToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.маникюрToolStripMenuItem,
            this.стрижкиToolStripMenuItem,
            this.массажToolStripMenuItem});
            this.каталогУслугToolStripMenuItem.Name = "каталогУслугToolStripMenuItem";
            this.каталогУслугToolStripMenuItem.Size = new System.Drawing.Size(114, 24);
            this.каталогУслугToolStripMenuItem.Text = "Каталог услуг";
            // 
            // маникюрToolStripMenuItem
            // 
            this.маникюрToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nnToolStripMenuItem,
            this.педикюрToolStripMenuItem,
            this.долговременноеПокрытиеToolStripMenuItem});
            this.маникюрToolStripMenuItem.Name = "маникюрToolStripMenuItem";
            this.маникюрToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.маникюрToolStripMenuItem.Text = "Nail-услуги";
            // 
            // nnToolStripMenuItem
            // 
            this.nnToolStripMenuItem.Name = "nnToolStripMenuItem";
            this.nnToolStripMenuItem.Size = new System.Drawing.Size(277, 26);
            this.nnToolStripMenuItem.Text = "Маникюр";
            // 
            // педикюрToolStripMenuItem
            // 
            this.педикюрToolStripMenuItem.Name = "педикюрToolStripMenuItem";
            this.педикюрToolStripMenuItem.Size = new System.Drawing.Size(277, 26);
            this.педикюрToolStripMenuItem.Text = "Педикюр";
            // 
            // долговременноеПокрытиеToolStripMenuItem
            // 
            this.долговременноеПокрытиеToolStripMenuItem.Name = "долговременноеПокрытиеToolStripMenuItem";
            this.долговременноеПокрытиеToolStripMenuItem.Size = new System.Drawing.Size(277, 26);
            this.долговременноеПокрытиеToolStripMenuItem.Text = "Долговременное покрытие";
            // 
            // стрижкиToolStripMenuItem
            // 
            this.стрижкиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.мужскиеToolStripMenuItem,
            this.женскиеToolStripMenuItem});
            this.стрижкиToolStripMenuItem.Name = "стрижкиToolStripMenuItem";
            this.стрижкиToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.стрижкиToolStripMenuItem.Text = "Парикмахерский сервис";
            // 
            // мужскиеToolStripMenuItem
            // 
            this.мужскиеToolStripMenuItem.Name = "мужскиеToolStripMenuItem";
            this.мужскиеToolStripMenuItem.Size = new System.Drawing.Size(146, 26);
            this.мужскиеToolStripMenuItem.Text = "Мужские";
            // 
            // женскиеToolStripMenuItem
            // 
            this.женскиеToolStripMenuItem.Name = "женскиеToolStripMenuItem";
            this.женскиеToolStripMenuItem.Size = new System.Drawing.Size(146, 26);
            this.женскиеToolStripMenuItem.Text = "Женские";
            // 
            // массажToolStripMenuItem
            // 
            this.массажToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.массажВсегоТелаToolStripMenuItem,
            this.массажГоловыToolStripMenuItem,
            this.массажСпиныToolStripMenuItem});
            this.массажToolStripMenuItem.Name = "массажToolStripMenuItem";
            this.массажToolStripMenuItem.Size = new System.Drawing.Size(255, 26);
            this.массажToolStripMenuItem.Text = "Массаж";
            // 
            // массажВсегоТелаToolStripMenuItem
            // 
            this.массажВсегоТелаToolStripMenuItem.Name = "массажВсегоТелаToolStripMenuItem";
            this.массажВсегоТелаToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.массажВсегоТелаToolStripMenuItem.Text = "Массаж всего тела";
            // 
            // массажГоловыToolStripMenuItem
            // 
            this.массажГоловыToolStripMenuItem.Name = "массажГоловыToolStripMenuItem";
            this.массажГоловыToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.массажГоловыToolStripMenuItem.Text = "Массаж головы";
            // 
            // массажСпиныToolStripMenuItem
            // 
            this.массажСпиныToolStripMenuItem.Name = "массажСпиныToolStripMenuItem";
            this.массажСпиныToolStripMenuItem.Size = new System.Drawing.Size(214, 26);
            this.массажСпиныToolStripMenuItem.Text = "Массаж спины";
            // 
            // прайслистToolStripMenuItem
            // 
            this.прайслистToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nailулсугиToolStripMenuItem,
            this.стрижкиToolStripMenuItem1,
            this.массажToolStripMenuItem1});
            this.прайслистToolStripMenuItem.Name = "прайслистToolStripMenuItem";
            this.прайслистToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.прайслистToolStripMenuItem.Text = "Прайс-лист";
            // 
            // nailулсугиToolStripMenuItem
            // 
            this.nailулсугиToolStripMenuItem.Name = "nailулсугиToolStripMenuItem";
            this.nailулсугиToolStripMenuItem.Size = new System.Drawing.Size(161, 26);
            this.nailулсугиToolStripMenuItem.Text = "Nail-улсуги";
            // 
            // стрижкиToolStripMenuItem1
            // 
            this.стрижкиToolStripMenuItem1.Name = "стрижкиToolStripMenuItem1";
            this.стрижкиToolStripMenuItem1.Size = new System.Drawing.Size(161, 26);
            this.стрижкиToolStripMenuItem1.Text = "Стрижки";
            // 
            // массажToolStripMenuItem1
            // 
            this.массажToolStripMenuItem1.Name = "массажToolStripMenuItem1";
            this.массажToolStripMenuItem1.Size = new System.Drawing.Size(161, 26);
            this.массажToolStripMenuItem1.Text = "Массаж";
            // 
            // выToolStripMenuItem
            // 
            this.выToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.вернутьсяНаГлавнуюToolStripMenuItem,
            this.выйиСУчетнойЗаписиToolStripMenuItem,
            this.закрытьПриложениеToolStripMenuItem});
            this.выToolStripMenuItem.Name = "выToolStripMenuItem";
            this.выToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.выToolStripMenuItem.Text = "Выход";
            // 
            // вернутьсяНаГлавнуюToolStripMenuItem
            // 
            this.вернутьсяНаГлавнуюToolStripMenuItem.Name = "вернутьсяНаГлавнуюToolStripMenuItem";
            this.вернутьсяНаГлавнуюToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.вернутьсяНаГлавнуюToolStripMenuItem.Text = "Вернуться на главную";
            this.вернутьсяНаГлавнуюToolStripMenuItem.Click += new System.EventHandler(this.вернутьсяНаГлавнуюToolStripMenuItem_Click);
            // 
            // выйиСУчетнойЗаписиToolStripMenuItem
            // 
            this.выйиСУчетнойЗаписиToolStripMenuItem.Name = "выйиСУчетнойЗаписиToolStripMenuItem";
            this.выйиСУчетнойЗаписиToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.выйиСУчетнойЗаписиToolStripMenuItem.Text = "Выйти с учетной записи";
            // 
            // закрытьПриложениеToolStripMenuItem
            // 
            this.закрытьПриложениеToolStripMenuItem.Name = "закрытьПриложениеToolStripMenuItem";
            this.закрытьПриложениеToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.закрытьПриложениеToolStripMenuItem.Text = "Закрыть приложение";
            this.закрытьПриложениеToolStripMenuItem.Click += new System.EventHandler(this.закрытьПриложениеToolStripMenuItem_Click);
            // 
            // MainMenuAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(236)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(480, 474);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainMenuAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Admin";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainMenuUser_FormClosed);
            this.Load += new System.EventHandler(this.MainMenuAdmin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem каталогУслугToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem маникюрToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem педикюрToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem долговременноеПокрытиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem стрижкиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem мужскиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem женскиеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem массажToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem массажВсегоТелаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem массажГоловыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem массажСпиныToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem прайслистToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nailулсугиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem стрижкиToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem массажToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem вернутьсяНаГлавнуюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выйиСУчетнойЗаписиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem закрытьПриложениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выйтиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выйтиВМенюРегистрацииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem закрытьПриложениеToolStripMenuItem1;
    }
}