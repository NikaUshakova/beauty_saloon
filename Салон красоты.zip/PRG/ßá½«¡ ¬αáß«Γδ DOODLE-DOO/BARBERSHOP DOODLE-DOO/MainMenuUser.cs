﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;


namespace BARBERSHOP_DOODLE_DOO
{
    public partial class MainMenuUser : Form
    {
        string[] filenames;
        int idfile=0;
        public MainMenuUser()
        {
            InitializeComponent();


            if (!this.DesignMode)
            {
                filenames = Directory.GetFiles("slaid", "*.png");
                this.timer1.Enabled = true;
                this.timer1.Interval = 3000;
                
            }
        }
       
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();          
           
        }

       

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = DOODLE_DOO.Properties.Resources.exit__;
            
        }

        private void MainMenuUser_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = DOODLE_DOO.Properties.Resources.exit;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (filenames.Length > 0)
            {
            if (this.pictureBox7.Image != null)                
                    this.pictureBox7.Image.Dispose();
               
            }

            try
            {
                //назначаем новую картинку
                this.pictureBox7.Image = Image.FromFile(filenames[idfile]);
                //наращиваем счетчик
                idfile++;
                if (idfile > filenames.Length-1)
                {
                    idfile = 0;
                }
            }
            catch
            {
                //в случае неудачи ставим null
                this.pictureBox7.Image = null;
            }
        }

        private void выйтиИзПрограммыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void менюРегистрацииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMenu mainMenu = new FormMenu();
            this.Hide();
            mainMenu.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            Record recordform = new Record();
            recordform.Size = new Size(597, 500);
            recordform.StartPosition = FormStartPosition.CenterScreen;
            recordform.Show();
            this.Hide();

        }

        private void предварительнаяЗаписьToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Record recordform = new Record();
            recordform.MaximumSize = new Size(597, 500);
            recordform.MinimumSize = new Size(597, 500);
            recordform.StartPosition = FormStartPosition.CenterScreen;
            recordform.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            _3D_katalog katalog = new _3D_katalog();
            katalog.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //new price
            Price price = new Price();
            price.Show();
            this.Hide();
        }

        private void парикмахерскийЗалToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _3D_katalog katalog = new _3D_katalog();
            katalog.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //new masters
            Masters masters = new Masters();
            masters.Show();
            this.Hide();
        }
    }
}
