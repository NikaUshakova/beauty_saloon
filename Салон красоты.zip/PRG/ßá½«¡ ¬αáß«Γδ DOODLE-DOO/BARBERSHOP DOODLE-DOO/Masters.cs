﻿using DOODLE_DOO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
namespace BARBERSHOP_DOODLE_DOO
{
    public partial class Masters : Form
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        List<string>[] ser = new List<string>[1];
        ListMasters listMasters = new ListMasters();
        public Masters()
        {
            InitializeComponent();
            server = "localhost";
            database = "salon_krasoti";
            uid = "root";
            password = "zapekanka333";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            connection = new MySqlConnection(connectionString);
        }

        private void Masters_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainMenuUser menuUser = new MainMenuUser();
            menuUser.Show();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            MainMenuUser menuUser = new MainMenuUser();
            menuUser.Show();
            this.Hide();
        }

        private void pictureBox10_MouseLeave(object sender, EventArgs e)
        {
            pictureBox10.Image = DOODLE_DOO.Properties.Resources.exit;
        }

        private void pictureBox10_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox10.Image = DOODLE_DOO.Properties.Resources.exit__;
        }
        public int number;
        private void pictureBox1_Click(object sender, EventArgs e)
        {           
            number = 5;
            SelectSer();
            listMasters.Text += "Долбаногов Артем";
            listMasters.Show();
        }
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                // MessageBox.Show("Соединение установлено!");
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }

        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public List<string>[] SelectSer()
        {
            string query = "SELECT service.Название from service Where service.id_master = " + number;

            ser[0] = new List<string>();
            //Open connection
            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();
               
                //Read the data and store them in the ser
               
                while (dataReader.Read())
                {
                    listMasters.dataGridView1.Rows.Add(dataReader["Название"]+" ") ;
                }
                for (int i = 0; i < listMasters.dataGridView1.Rows.Count; i++)
                {
                    if (i % 2 == 0)
                    {
                        listMasters.dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(222, 236, 255);
                    }
                    else
                    {
                        listMasters.dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(243, 248, 255);
                    }
                }
              
                //close Data Reader
                dataReader.Close();

                //close Connection
                CloseConnection();

                //return list to be displayed
                return ser;
            }
            
            else
            {
                return ser;
            }
           
        }
    

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            number = 12;
            SelectSer();
            listMasters.Text += "Ковалевский Никита";
            listMasters.Show();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            number = 11;
            SelectSer();
            listMasters.Text += "Антонович Александр";
            listMasters.Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            number = 10;
            SelectSer();
            listMasters.Text += "Яблонский Олег";
            listMasters.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            number = 1;
            SelectSer();
            listMasters.Text += "Цагойко Лёня";
            listMasters.Show();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            number = 3;
            SelectSer();
            listMasters.Text += "Ушакова Ника";
            listMasters.Show();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            number = 2;
            SelectSer();
            listMasters.Text += "Чевнова Юлия";
            listMasters.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            number = 6;
            SelectSer();
            listMasters.Text += "Лазовенко Андрюха";
            listMasters.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            number = 4;
            SelectSer();
            listMasters.Text += "Саджитов Алек";
            listMasters.Show();
        }
    }
}
