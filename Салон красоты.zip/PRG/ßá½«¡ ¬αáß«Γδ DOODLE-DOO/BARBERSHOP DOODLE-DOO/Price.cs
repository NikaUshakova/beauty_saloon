﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;
namespace BARBERSHOP_DOODLE_DOO
{
    public partial class Price : Form
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        List<string[]> service = new List<string[]>();
        public Price()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            server = "localhost";
            database = "salon_krasoti";
            uid = "root";
            password = "zapekanka333";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            connection = new MySqlConnection(connectionString);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainMenuUser menuUser = new MainMenuUser();
            menuUser.Show();
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = DOODLE_DOO.Properties.Resources.exit__;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = DOODLE_DOO.Properties.Resources.exit;
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                // MessageBox.Show("Соединение установлено!");
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }



        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public List<string[]> SelectPrice()
        {
            string query = "SELECT service.id, service.Название,service.Цена FROM service ";

            //Open connection
            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();
                service.Clear();
                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    service.Add(new string[3]);
                    service[service.Count - 1][0] = dataReader[0].ToString();
                    service[service.Count - 1][1] = dataReader[1].ToString();
                    service[service.Count - 1][2] = dataReader[2].ToString();
                  
                }
                RefreshInfo();
                //close Data Reader
                dataReader.Close();

                //close Connection
                this.CloseConnection();

                //return list to be displayed
                return service;
            }
            else
            {
                return service;
            }
        }
        public void RefreshInfo()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < service.Count; i++)
            {
                if (i % 2 == 0)
                {
                    dataGridView1.Rows.Add(service[i]);
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(222, 236, 255);
                }
                else
                {
                    dataGridView1.Rows.Add(service[i]);
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(243, 248, 255);
                }

            }
        }

        private void Price_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;            
            SelectPrice();
        }

        private void Price_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainMenuUser menuUser = new MainMenuUser();
            menuUser.Show();
        }
    }
}
