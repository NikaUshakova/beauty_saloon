﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace BARBERSHOP_DOODLE_DOO
{
    public partial class Record : Form
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        List<string[]> service = new List<string[]>();

        public Record()
        {
            InitializeComponent();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            combomobile.KeyPress += (sender, e) => e.Handled = true;
            comboBox1.KeyPress += (sender, e) => e.Handled = true;
            server = "localhost";
            database = "salon_krasoti";
            uid = "root";
            password = "zapekanka333";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            connection = new MySqlConnection(connectionString);
        }

        private bool OpenConnection()
        {
            try
            {
                connection.Open();
               // MessageBox.Show("Соединение установлено!");
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }



        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        string type = "";
        private void label7_Click(object sender, EventArgs e)
        {
            type = "М";
            //dataGridView1.Size = new Size(550, 340);
            dataGridView1.Visible = true;
           
            SelectService();
        }
        private void label8_Click(object sender, EventArgs e)
        {
            type = "Ж";

            dataGridView1.Visible = true;

            SelectService();
        }

        private void label9_Click(object sender, EventArgs e)
        {
            type = "П";
           
            dataGridView1.Visible = true;
          
            SelectService();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            type = "Массаж";
            
            dataGridView1.Visible = true;
           
            SelectService();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            
            type = "Н";
           
            dataGridView1.Visible = true;
            
            SelectService();

        }
        public List<string[]> SelectService()
        {
            string query = "SELECT service.id, service.Название,service.Цена, masters.ФИО_мастера FROM service LEFT OUTER JOIN masters ON service.id_master=masters.id  WHERE service.Тип='"+type+"'";
              
            //Open connection
            if (this.OpenConnection() == true)
            {
                //Create Command
                MySqlCommand cmd = new MySqlCommand(query, connection);
                //Create a data reader and Execute the command
                MySqlDataReader dataReader = cmd.ExecuteReader();
                service.Clear();
                //Read the data and store them in the list
                while (dataReader.Read())
                {
                    service.Add(new string[4]);
                    service[service.Count - 1][0] = dataReader[0].ToString();
                    service[service.Count - 1][1] = dataReader[1].ToString();
                    service[service.Count - 1][2] = dataReader[2].ToString();
                    service[service.Count - 1][3] = dataReader[3].ToString();
                   
                   
                }
                RefreshInfo();
                //close Data Reader
                dataReader.Close();

                //close Connection
                this.CloseConnection();

                //return list to be displayed
                return service;
            }
            else
            {
                return service;
            }
        }

        public void RefreshInfo()
        {
            dataGridView1.Rows.Clear();
            for (int i = 0; i < service.Count; i++)
            {
                if (i % 2 == 0)
                {
                    dataGridView1.Rows.Add(service[i]);
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(222, 236, 255); 
                }
                else
                {
                    dataGridView1.Rows.Add(service[i]);
                    dataGridView1.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(243, 248, 255);
                }
            }
        }

        private void Record_Load(object sender, EventArgs e)
        {
           label5.Text = "";  
        }

        private void buttonYes_Click(object sender, EventArgs e)
        {
            if (username.Text!="" && usersurname.Text!=""&&adressbox.Text!=""&& combomobile.SelectedIndex!=-1 && long.Parse(mobilebox.Text)!=0)
         {
             string name = username.Text;
             string surname = usersurname.Text;
             string birthday = dateHBuser.Text.ToString();
             string adress = adressbox.Text;
             string number = combomobile.SelectedItem.ToString();
             string number2 = mobilebox.Text;
             string mobile = number + number2;
             

            pictureBox1.Image = DOODLE_DOO.Properties.Resources.number1;
                pictureBox5.Image = DOODLE_DOO.Properties.Resources.arrow;
                pictureBox2.Image = DOODLE_DOO.Properties.Resources.number2__;
                buttonYes2.Enabled = true;
            this.MaximumSize = new Size(900, 640);
            this.MinimumSize = new Size(900, 640);
            
                this.Left= 200;
                this.Top = 100;
            groupBox1.Visible = false;
                groupBox2.Visible = true;

            }
           else
            {
               MessageBox.Show("Проверьте введенные данные!", "Ошибка!");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                //MessageBox.Show(dataGridView1.SelectedRows.Count.ToString());
                pictureBox2.Image = DOODLE_DOO.Properties.Resources.number2;
                pictureBox6.Image = DOODLE_DOO.Properties.Resources.arrow;
                pictureBox3.Image = DOODLE_DOO.Properties.Resources.number3__;
                buttonYes4.Enabled = true;
                this.MaximumSize = new Size(559, 360);
                this.MinimumSize = new Size(559, 360);
                this.Left = 300;
                this.Top = 100;
                groupBox2.Visible = false;
                groupBox3.Visible = true;
            }
           else
            {
                MessageBox.Show("Выберите услугу!", "Attention!");
                return;
            }

        }

        public void Insert_Into()                                                                                                                                           
        {
            try
            {
                string query = "INSERT INTO clients VALUES (0,'" + usersurname.Text + " " + username.Text + "','" + dateHBuser.Text + "','" +
                                   adressbox.Text + "','" + combomobile.SelectedItem.ToString() + mobilebox.Text + "','" +
                                   monthCalendar1.SelectionStart.ToLongDateString() + "','" + comboBox1.SelectedItem + "'," + dataGridView1.CurrentRow.Cells[0].Value + ");";

                //open connection
                if (this.OpenConnection() == true)
                {
                    //create command and assign the query and connection from the constructor
                    MySqlCommand cmd = new MySqlCommand(query, connection);

                    //Execute command
                    cmd.ExecuteNonQuery();

                    //close connection
                    this.CloseConnection();
                }
            }
            catch
            {
                MessageBox.Show("Какая-то ошибка");
                return;
            }
        }

        private void buttonYes4_Click(object sender, EventArgs e)
        { 
            MainMenuUser menuUser = new MainMenuUser();
            if (monthCalendar1.SelectionStart.ToLongDateString() != "" && comboBox1.SelectedIndex != -1)
            {
                
                MessageBox.Show("Ваша заявка отправлена! Мы свяжемся с вами в течении часа.", "Сообщение");
                Insert_Into();
                this.Close();

                
               
            }
            else
            {
                MessageBox.Show("Выберите дату и время!", "Attention");
                return;
            }
        
           
            
        }


        private void username_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)
                e.Handled = true;
            return;
        }

        private void usersurname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsLetter(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)
                e.Handled = true;
            return;
        }

        private void mobilebox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != (char)Keys.Delete)
                e.Handled = true;
            return;
        }

        private void monthCalendar1_DateChanged(object sender,  DateRangeEventArgs e)
        {            
            DateTime day = monthCalendar1.SelectionStart;
            if (day >= monthCalendar1.TodayDate)
            {
                comboBox1.Enabled = true;
               
            }
            else
            {
                MessageBox.Show("Записаться на прошедшие дни низя", "Attention");
                return;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            label5.Text = String.Format("Вы выбрали: " + monthCalendar1.SelectionStart.ToLongDateString() + " время: "+comboBox1.SelectedItem);
        }

        private void label11_MouseMove(object sender, MouseEventArgs e)
        {
            label11.ForeColor = Color.DarkBlue;
        }

        private void label10_MouseMove(object sender, MouseEventArgs e)
        {
            label10.ForeColor = Color.DarkBlue;
        }

        private void label9_MouseMove(object sender, MouseEventArgs e)
        {
            label9.ForeColor = Color.DarkBlue;
        }

        private void label8_MouseMove(object sender, MouseEventArgs e)
        {
            label8.ForeColor = Color.DarkBlue;
        }

        private void label7_MouseMove(object sender, MouseEventArgs e)
        {
            label7.ForeColor = Color.DarkBlue;
        }

        private void label7_MouseLeave(object sender, EventArgs e)
        {
            label7.ForeColor = Color.Black;
        }

        private void label8_MouseLeave(object sender, EventArgs e)
        {
            label8.ForeColor = Color.Black;
        }

        private void label9_MouseLeave(object sender, EventArgs e)
        {
            label9.ForeColor = Color.Black;
        }

        private void label10_MouseLeave(object sender, EventArgs e)
        {
            label10.ForeColor = Color.Black;
        }

        private void label11_MouseLeave(object sender, EventArgs e)
        {
            label11.ForeColor = Color.Black;
        }

        private void Record_FormClosed(object sender, FormClosedEventArgs e)
        {
            MainMenuUser menuUser = new MainMenuUser();
            menuUser.Show();
        }
    }
}
